// UdfRegister.cpp

#include "StdAfx.h"

#include "../../Common/RegisterArc.h"

#include "UdfHandler.h"
