// Windows/ProcessMessages.h

#ifndef __WINDOWS_PROCESSMESSAGES_H
#define __WINDOWS_PROCESSMESSAGES_H

namespace NWindows {

void ProcessMessages(HWND window);

}

#endif


