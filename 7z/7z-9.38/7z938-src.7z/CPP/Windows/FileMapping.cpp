// Windows/FileMapping.cpp

#include "StdAfx.h"

#include "FileMapping.h"

namespace NWindows {
namespace NFile {
namespace NMapping {


}}}
