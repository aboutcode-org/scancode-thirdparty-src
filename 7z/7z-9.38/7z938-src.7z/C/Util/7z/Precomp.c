/* Precomp.c -- StdAfx
2013-01-21 : Igor Pavlov : Public domain */

#include "Precomp.h"
